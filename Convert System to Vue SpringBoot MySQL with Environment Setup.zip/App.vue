<template>
  <router-view />
</template>

<script setup>
</script>

<style>
#app {
  width: 100%;
  height: 100%;
}
</style>
