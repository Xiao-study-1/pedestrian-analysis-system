// 全局变量
let violationChart, behaviorChart, disposalChart, flowChart;
let areaCharts = [];
let heatmapScene, heatmapCamera, heatmapRenderer, heatmapControls;
let isRotating = false;
let rotationSpeed = 0.005;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initCharts();
    initHeatmap3D();
    initEventListeners();
    startDataUpdates();
});

// 初始化所有图表
function initCharts() {
    initViolationChart();
    initBehaviorChart();
    initDisposalChart();
    initFlowChart();
    initAreaCharts();
}

// 初始化行人违规行为TOP5柱状图
function initViolationChart() {
    const ctx = document.getElementById('violationChart').getContext('2d');
    
    // 数据
    const labels = ['闯红灯', '违规横穿', '路口逗留', '逆行', '违规骑行'];
    const data = [381, 87, 87, 70, 64];
    const backgroundColors = [
        '#39FF14', // 荧光绿（最高频）
        '#00E5FF', // 科技蓝
        '#00E5FF',
        '#00E5FF',
        '#00E5FF'
    ];
    
    // 创建图表
    violationChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: '违规次数',
                data: data,
                backgroundColor: backgroundColors,
                borderColor: 'rgba(0, 229, 255, 0.5)',
                borderWidth: 1,
                borderRadius: 4,
                barPercentage: 0.6,
                categoryPercentage: 0.7
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(10, 37, 64, 0.9)',
                    titleColor: '#00E5FF',
                    bodyColor: 'white',
                    borderColor: 'rgba(0, 229, 255, 0.5)',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            const locations = [
                                '学校门口路口',
                                '商业街路口',
                                '医院门口',
                                '地铁站出口',
                                '公园入口'
                            ];
                            return `${context.label}：${locations[context.dataIndex]} ${context.raw}次`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(0, 229, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                y: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            },
            onHover: (event, elements) => {
                event.native.target.style.cursor = elements.length ? 'pointer' : 'default';
            }
        }
    });
    
    // 添加点击事件
    document.getElementById('violationChart').onclick = function(evt) {
        const points = violationChart.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, true);
        
        if (points.length) {
            const firstPoint = points[0];
            const label = violationChart.data.labels[firstPoint.index];
            
            // 模拟联动效果
            if (label === '闯红灯') {
                highlightHeatmapArea('school');
                filterFlowData('school');
            }
        }
    };
}

// 初始化行人行为类型占比环形图
function initBehaviorChart() {
    const ctx = document.getElementById('behaviorChart').getContext('2d');
    
    // 数据
    const data = {
        labels: ['合规通行', '闯红灯', '违规横穿', '其他', '路口逗留'],
        datasets: [{
            data: [43, 30, 13, 8, 6],
            backgroundColor: [
                '#39FF14', // 荧光绿
                '#FF3131', // 红色
                '#FFA500', // 橙色
                '#00E5FF', // 科技蓝
                '#9370DB'  // 紫色
            ],
            borderColor: '#081A2D',
            borderWidth: 2,
            hoverOffset: 10
        }]
    };
    
    // 创建图表
    behaviorChart = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        padding: 10,
                        font: {
                            size: 10
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(10, 37, 64, 0.9)',
                    titleColor: '#00E5FF',
                    bodyColor: 'white',
                    borderColor: 'rgba(0, 229, 255, 0.5)',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: true
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true
            }
        }
    });
    
    // 添加中心文本
    const centerTextPlugin = {
        id: 'centerText',
        beforeDraw: function(chart) {
            if (chart.config.type === 'doughnut') {
                const width = chart.width;
                const height = chart.height;
                const ctx = chart.ctx;
                
                ctx.restore();
                ctx.font = 'bold 14px Arial';
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.fillStyle = '#00E5FF';
                ctx.fillText('总分析样本', width / 2, height / 2 - 10);
                
                ctx.font = 'bold 18px Arial';
                ctx.fillStyle = 'white';
                ctx.fillText('2000 次', width / 2, height / 2 + 10);
                
                ctx.save();
            }
        }
    };
    
    Chart.register(centerTextPlugin);
}

// 初始化行为处置结果占比双环形图
function initDisposalChart() {
    const ctx = document.getElementById('disposalChart').getContext('2d');
    
    // 数据
    const data = {
        labels: ['和解劝离案件', '引导整改案件', '罚款警示案件', '其他处置'],
        datasets: [
            {
                data: [20.8, 20.8, 20.8, 37.6],
                backgroundColor: [
                    '#39FF14', // 荧光绿
                    '#00E5FF', // 科技蓝
                    '#FFA500', // 橙色
                    'rgba(255, 255, 255, 0.1)'
                ],
                borderColor: '#081A2D',
                borderWidth: 2,
                hoverOffset: 10
            }
        ]
    };
    
    // 创建图表
    disposalChart = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        padding: 10,
                        font: {
                            size: 10
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(10, 37, 64, 0.9)',
                    titleColor: '#00E5FF',
                    bodyColor: 'white',
                    borderColor: 'rgba(0, 229, 255, 0.5)',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            return `${context.label}：${context.raw}%`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true
            }
        }
    });
}

// 初始化行人流量变化趋势图
function initFlowChart() {
    const ctx = document.getElementById('flowChart').getContext('2d');
    
    // 数据
    const labels = ['周一', '周二', '周三', '周四', '周五'];
    const lineData = [3200, 3500, 3100, 3800, 4200]; // 日均人流量
    const barData = [4500, 4800, 4300, 5100, 5500];  // 高峰时段人数
    
    // 创建图表
    flowChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '日均人流量',
                    data: lineData,
                    type: 'line',
                    borderColor: '#39FF14',
                    backgroundColor: 'rgba(57, 255, 20, 0.1)',
                    borderWidth: 2,
                    pointBackgroundColor: '#39FF14',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: '高峰时段人数',
                    data: barData,
                    backgroundColor: 'rgba(0, 229, 255, 0.6)',
                    borderColor: 'rgba(0, 229, 255, 0.8)',
                    borderWidth: 1,
                    borderRadius: 4,
                    barPercentage: 0.6,
                    categoryPercentage: 0.7,
                    yAxisID: 'y'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        padding: 10,
                        font: {
                            size: 10
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(10, 37, 64, 0.9)',
                    titleColor: '#00E5FF',
                    bodyColor: 'white',
                    borderColor: 'rgba(0, 229, 255, 0.5)',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            const time = context.datasetIndex === 0 ? '日均' : '早高峰';
                            return `时间：${context.label}${time}，人流量：${context.raw} 人`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(0, 229, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(0, 229, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        callback: function(value) {
                            return value + ' 人';
                        }
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    });
}

// 初始化涉违规区域分布情况环形图组
function initAreaCharts() {
    const areaData = [
        { id: 'areaChart1', data: [20.8, 79.2], color: '#39FF14' },
        { id: 'areaChart2', data: [20.8, 79.2], color: '#00E5FF' },
        { id: 'areaChart3', data: [20.8, 79.2], color: '#FFA500' },
        { id: 'areaChart4', data: [20.8, 79.2], color: '#9370DB' }
    ];
    
    areaData.forEach(item => {
        const ctx = document.getElementById(item.id).getContext('2d');
        
        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: item.data,
                    backgroundColor: [
                        item.color,
                        'rgba(255, 255, 255, 0.05)'
                    ],
                    borderColor: '#081A2D',
                    borderWidth: 1,
                    cutout: '85%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true
                }
            }
        });
        
        areaCharts.push(chart);
        
        // 添加点击事件
        document.getElementById(item.id).onclick = function() {
            showAreaDetail(item.id);
        };
    });
}

// 初始化3D热力图
function initHeatmap3D() {
    // 创建场景
    heatmapScene = new THREE.Scene();
    heatmapScene.background = new THREE.Color(0x0A2540);
    
    // 创建相机
    heatmapCamera = new THREE.PerspectiveCamera(
        60,
        document.getElementById('heatmap3D').clientWidth / document.getElementById('heatmap3D').clientHeight,
        0.1,
        1000
    );
    heatmapCamera.position.set(10, 10, 10);
    heatmapCamera.lookAt(0, 0, 0);
    
    // 创建渲染器
    heatmapRenderer = new THREE.WebGLRenderer({ antialias: true });
    heatmapRenderer.setSize(
        document.getElementById('heatmap3D').clientWidth,
        document.getElementById('heatmap3D').clientHeight
    );
    document.getElementById('heatmap3D').appendChild(heatmapRenderer.domElement);
    
    // 添加光源
    const ambientLight = new THREE.AmbientLight(0x404040, 2);
    heatmapScene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 10, 7.5);
    heatmapScene.add(directionalLight);
    
    // 创建网格
    createGrid();
    
    // 创建热力柱
    createHeatmapColumns();
    
    // 添加控制器
    addHeatmapControls();
    
    // 开始动画循环
    animateHeatmap();
    
    // 添加窗口大小变化监听
    window.addEventListener('resize', onHeatmapResize);
}

// 创建网格
function createGrid() {
    const gridSize = 10;
    const gridDivisions = 10;
    
    const gridHelper = new THREE.GridHelper(gridSize, gridDivisions, 0x00E5FF, 0x00E5FF);
    gridHelper.material.opacity = 0.2;
    gridHelper.material.transparent = true;
    heatmapScene.add(gridHelper);
}

// 创建热力柱
function createHeatmapColumns() {